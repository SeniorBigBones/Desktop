package com.company;

public class Main {

    public static void main(String[] args) {
        products I0021= new products("Pineapple",30,2.99);
        products I0022= new products("Suspicious Looking Chest",2,21.00);
        products I0023= new products("Single Sock", 53,2.00);
        products I0024= new products("Really old stained bricks",55,5.00);

    }
}
