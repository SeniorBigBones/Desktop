package com.company;

class products {
    String name;
    int quantity;
    double price;

    //Constructor
    products(String Name, int Quantity, double Price) {
        this.name = Name;
        this.quantity = Quantity;
        this.price = Price;


    }
}
